<?php
if( !empty( $instance['title'] ) )  {
	
	$add_class = '';
	if( !empty( $instance['with-line'] ) ) {
		$add_class .= ' title-with-line';
	}
	
	if( !empty( $instance['align'] ) ) {
		$add_class .= ' title-align-'. $instance['align'];
	}
	
	echo '<div class="widget-title-container'. $add_class .'">';
		echo $args['before_title'] . esc_html($instance['title']) . $args['after_title'];
		
		if( !empty( $instance['subtitle'] ) )  {
			echo '<p class="widget-sub-title">'. $instance['subtitle'] .'</p>';
		}
	echo '</div>';
}
?>

<div class="siteorigin-widget-tinymce textwidget">
	<?php echo $text; ?>
</div>