(function($){
	$(function(){
		//console.log('Load Widget Scripts');
	});
})(jQuery)