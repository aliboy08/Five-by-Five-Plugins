<?php
/*
 *  Plugin Name: Five by Five Extend SiteOrigin Widgets Bundle
 *	Description: Five by Five Extensions to SiteOrigin Widgets
 *	Author: Five by Five
 */

if ( ! defined( 'WPINC' ) ) die;

// Register Custom Widgets Directory
function add_ff_widgets_collection($folders){
    //$folders[] = get_stylesheet_directory_uri() .'/extend-widgets-bundle/';
    $folders[] = plugin_dir_path(__FILE__) .'/extend-widgets-bundle/';
    return $folders;
}
add_filter('siteorigin_widgets_widget_folders', 'add_ff_widgets_collection');