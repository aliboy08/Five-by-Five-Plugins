(function($){
	$(function(){
		
		$('.ff-steps').each( function(){

			var $this = $(this),
				nav_item = $this.find('.nav-item'),
				content = $this.find('.step-content'),
				nav_dropdown = $this.find('.nav-dropdown select');

			// Nav
			nav_item.on('click', function(e){
				e.preventDefault();
				content.removeClass('active');
				nav_item.removeClass('active');
				$(this).addClass('active');
				$this.find('.step-content-'+ $(this).data('step')).addClass('active');
			});

			// Nav - Dropdown
			nav_dropdown.on('change', function(){
				content.removeClass('active');
				nav_item.removeClass('active');
				$(this).addClass('active');
				$this.find('.step-content-'+ $(this).val()).addClass('active');
			});

		});

	});
})(jQuery);