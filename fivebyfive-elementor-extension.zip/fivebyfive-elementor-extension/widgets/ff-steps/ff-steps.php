<?php
namespace FFElementorExtensions\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class FF_Steps extends Widget_Base {
    
	public function get_name() {
		return 'ff-steps';
    }
    
	public function get_title() {
		return __( 'FF Steps', 'fivebyfive' );
    }
    
	public function get_icon() {
		return 'eicon-tabs';
    }
    
	public function get_categories() {
		return [ 'fivebyfive' ];
	}
	
	public function get_keywords() {
		return [ 'tab', 'tabs', 'step', 'steps' ];
	}

	public function get_style_depends() {
		return [ 'ff-steps-styles' ];
	}

	public function get_script_depends() {
		return [ 'ff-steps-scripts' ];
	}
    
	protected function _register_controls() {

		// Content Tab Settings
   		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'fivebyfive' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'step_num', [
				'label' => __( 'Number', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '' , 'fivebyfive' ),
			]
		);

		// Title
		$repeater->add_control(
			'step_title', [
				'label' => __( 'Title', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Title here' , 'fivebyfive' ),
				'label_block' => true,
			]
		);

		// Content - Column 1
		$repeater->add_control(
			'step_content_col_1', [
				'label' => __( 'Content - Column 1', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '' , 'fivebyfive' ),
				'label_block' => true,
			]
		);

		// Content - Column 2
		$repeater->add_control(
			'step_content_col_2', [
				'label' => __( 'Content - Column 2', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( '' , 'fivebyfive' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'steps',
			[
				'label' => __( 'List', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ step_title }}}',
			]
		);

		$this->add_control(
			'show_indicator',
			[
				'label' => __( 'Show Indicator', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'fivebyfive' ),
				'label_off' => __( 'Hide', 'fivebyfive' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

  	}
    
	protected function render() {

		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			//return; // Don't display on edit mode, css file is not loaded
		}
		
		$settings = $this->get_settings_for_display();

		$add_class = ( $settings['show_indicator'] == 'yes' ) ? ' with-indicator'  : '';

		echo '<div class="ff-steps'. $add_class .'">';

			$nav = '';
			$nav_dropdown = '';
			$content = '';
			
			$i = 0;
			foreach ( $settings['steps'] as $index => $item ) { $i++;

				$active = ( $i == 1 ) ? ' active' : ''; // Set first item active 

				// Nav
				$nav .= '<div class="nav-item nav-item-'. $i . $active .'" data-step="'. $i .'">';
					if( $item['step_num'] ) {
						$nav .= '<span class="step-num">'. $item['step_num'] .'</span>';
					}
					$nav .= '<span class="step-title">'. $item['step_title'] .'</span>';
				$nav .= '</div>';

				// Nav dropdown - for mobile
				$nav_dropdown .= '<option value="'. $i .'">'. $item['step_title'] .'</option>';
				
				// Content
				$content .= '<div class="step-content step-content-'. $i . $active .'">';
					$content .= '<div class="flex-container">';
					if( $item['step_content_col_1'] ) {
						$content .= '<div class="c c1">'. do_shortcode( $item['step_content_col_1'] ) .'</div>';
					}
					if( $item['step_content_col_2'] ) {
						$content .= '<div class="c c2">'. do_shortcode( $item['step_content_col_2'] ) .'</div>';
					}
					$content .= '</div>';
				$content .= '</div>';
				
			}

			echo '<div class="nav">'. $nav .'</div>';

			echo '<div class="nav-dropdown"><select>'. $nav_dropdown .'</select></div>';

			echo '<div class="step-content-container">'. $content .'</div>';

		echo '</div>';
	}

}