<?php
namespace FFElementorExtensions\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class FF_List extends Widget_Base {
    
	public function get_name() {
		return 'ff-list';
    }
    
	public function get_title() {
		return __( 'FF List', 'fivebyfive' );
    }
    
	public function get_icon() {
		return 'eicon-bullet-list';
    }
    
	public function get_categories() {
		return [ 'fivebyfive' ];
	}
	
	public function get_keywords() {
		return [ 'list' ];
	}
    
	protected function _register_controls() {

		// Content Tab Settings
   		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'fivebyfive' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$repeater = new \Elementor\Repeater();

		// Title
		$repeater->add_control(
			'list_title', [
				'label' => __( 'Title', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'List Title' , 'fivebyfive' ),
				'label_block' => true,
			]
		);

		// Content
		$repeater->add_control(
			'list_content', [
				'label' => __( 'Content', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => __( 'List Content' , 'fivebyfive' ),
				'show_label' => false,
			]
		);

		// Link
		// $repeater->add_control(
		// 	'list_link', [
		// 		'label' => __( 'Link', 'fivebyfive' ),
		// 		'type' => \Elementor\Controls_Manager::URL,
		// 		'dynamic' => [
		// 			'active' => true,
		// 		],
		// 		'label_block' => true,
		// 		'placeholder' => __( 'https://your-link.com', 'fivebyfive' ),
		// 		'separator' => 'before',
		// 	]
		// );

		$this->add_control(
			'list',
			[
				'label' => __( 'List', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( '', 'fivebyfive' ),
						'list_content' => __( '', 'fivebyfive' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

		$this->add_control(
			'class',
			[
				'label' => __( 'Class', 'fivebyfive' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$this->end_controls_section();
		// Content Tab Settings

		// Styles Tab Settings
		$this->start_controls_section(
			'section_icon_list',
			[
				'label' => __( 'List', 'elementor' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'space_between',
			[
				'label' => __( 'Space Between', 'elementor' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child)' => 'padding-bottom: calc({{SIZE}}{{UNIT}}/2)',
					'{{WRAPPER}} .ff-list .r:not(:first-child)' => 'margin-top: calc({{SIZE}}{{UNIT}}/2)',
				],
			]
		);

		$this->add_responsive_control(
			'icon_align',
			[
				'label' => __( 'Alignment', 'elementor' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-h-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-h-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-h-align-right',
					],
				],
				'prefix_class' => 'elementor%s-align-',
			]
		);

		$this->add_control(
			'divider',
			[
				'label' => __( 'Divider', 'elementor' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_off' => __( 'Off', 'elementor' ),
				'label_on' => __( 'On', 'elementor' ),
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'content: ""; position: absolute;',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'divider_style',
			[
				'label' => __( 'Style', 'elementor' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'solid' => __( 'Solid', 'elementor' ),
					'double' => __( 'Double', 'elementor' ),
					'dotted' => __( 'Dotted', 'elementor' ),
					'dashed' => __( 'Dashed', 'elementor' ),
				],
				'default' => 'solid',
				'condition' => [
					'divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'border-top-style: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'divider_weight',
			[
				'label' => __( 'Weight', 'elementor' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
					'size' => 1,
				],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
					],
				],
				'condition' => [
					'divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'border-top-width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		$this->add_control(
			'divider_width',
			[
				'label' => __( 'Width', 'elementor' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'default' => [
					'unit' => '%',
				],
				'condition' => [
					'divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'width: {{SIZE}}{{UNIT}}',
				],
			]
		);

		// $this->add_control(
		// 	'divider_height',
		// 	[
		// 		'label' => __( 'Height', 'elementor' ),
		// 		'type' => \Elementor\Controls_Manager::SLIDER,
		// 		'size_units' => [ '%', 'px' ],
		// 		'default' => [
		// 			'unit' => '%',
		// 		],
		// 		'range' => [
		// 			'px' => [
		// 				'min' => 1,
		// 				'max' => 100,
		// 			],
		// 			'%' => [
		// 				'min' => 1,
		// 				'max' => 100,
		// 			],
		// 		],
		// 		'condition' => [
		// 			'divider' => 'yes',
		// 			'view' => 'inline',
		// 		],
		// 		'selectors' => [
		// 			'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'height: {{SIZE}}{{UNIT}}',
		// 		],
		// 	]
		// );

		$this->add_control(
			'divider_color',
			[
				'label' => __( 'Color', 'elementor' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ddd',
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_3,
				],
				'condition' => [
					'divider' => 'yes',
				],
				'selectors' => [
					'{{WRAPPER}} .ff-list .r:not(:last-child):after' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
		// Styles Tab Settings

  	}
    
	protected function render() {
		$settings = $this->get_settings_for_display();
		$add_class = ( $settings['class'] ) ? ' '. $settings['class'] : '';
		echo '<div class="ff-list'. $add_class .'">';
			foreach (  $settings['list'] as $index => $item ) {
				echo '<div class="r list-item-'. $item['_id'] .'">';
					echo '<div class="c c1">'. $item['list_title'] .'</div>';
					echo '<div class="c c2">' . $item['list_content'] . '</div>';
				echo '</div>';
			}
		echo '</div>';
	}

}