<?php
namespace FFElementorExtensions;

/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class Plugin {

	/**
	 * Instance
	 *
	 * @since 1.2.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.2.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	public function register_widget_scripts() {
		wp_register_script( 'ff-steps-scripts', plugins_url( '/widgets/ff-steps/js/ff-steps.js', __FILE__ ), [ 'jquery' ], null, true );
	}
	
	public function register_widget_styles() {
		wp_register_style( 'ff-steps-styles', plugins_url( '/widgets/ff-steps/css/ff-steps.css', __FILE__ ) );
	}

	// Not needed anymore, after elementor update
	// public function editor_enqueue_widget_scripts() {
	// 	wp_enqueue_script( 'ff-steps-scripts' );
	// }

	// Not needed anymore, after elementor update
	// public function editor_enqueue_widget_styles() {
	// 	wp_enqueue_style( 'ff-steps-styles' );
	// }

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.2.0
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/ff-list.php' );
		require_once( __DIR__ . '/widgets/ff-steps/ff-steps.php' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();
		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\FF_List() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\FF_Steps() );
	}

	/**
	 *  Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function __construct() {
		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		// Register widget scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_widget_scripts' ] );
		
		// Register Widget Styles
		add_action( 'elementor/frontend/after_register_styles', [ $this, 'register_widget_styles' ] );

		// Enqueue Widget Styles on Editor / Preview Mode
		// Not needed anymore, after elementor update
		//add_action( 'elementor/preview/enqueue_styles', [ $this, 'editor_enqueue_widget_styles' ] );

		// Enqueue Widget Scripts on Editor / Preview Mode
		// Not needed anymore, after elementor update
		//add_action( 'elementor/preview/enqueue_scripts', [ $this, 'editor_enqueue_widget_scripts' ] );
	}
}

// Instantiate Plugin Class
Plugin::instance();