<?php
/*
Plugin Name: Five by Five Form Steps
Description: Transform form into multi-steps
Author: Five by Five
Author URI: https://www.fivebyfive.com.au
Version: 1.0
*/

if ( !defined( 'WPINC' ) ) { die; }

// [ff_form_steps id=13 title=false description=false ajax=true tabindex=70]

add_shortcode( 'ff_form_steps', 'ff_form_steps' );
function ff_form_steps ( $atts ) {
	ob_start();

	// Load assets
	wp_enqueue_style( 'ff-form-steps', plugin_dir_url( __FILE__ ) .'assets/css/ff-form-steps.css' );
	wp_enqueue_script( 'ff-form-steps', plugin_dir_url( __FILE__ ) .'assets/js/ff-form-steps.js', array( 'jquery' ), null, true );

	$gf_atts = '';
	foreach( $atts as $k => $v ) {
		$gf_atts .= ' '. $k .'='. $v;
	}
	echo '<div class="ff-form-steps" style="display:none;">'. do_shortcode('[gravityform'. $gf_atts .']') . '</div>';
	return ob_get_clean();
}