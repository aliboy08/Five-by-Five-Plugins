(function($){
	$(function(){
		console.log('ff-step-form.js');
		
		$('.ff-form-steps').each(function() {
			var $this = $(this),
				$form = $this.find('form'),
				$fields = $this.find('li.gfield:not(.gform_validation_container)'),
				total_fields = $fields.length,
				$back_btn,
				$custom_submit_btn;

			$this.addClass('init').css('display', 'block');
			
			// Set initial index
			var current_index = 1;
			
			$fields.addClass('hide flip-in-ver-left');

			// show initial field
			$this.find('li.gfield:eq('+ (current_index-1) +')').removeClass('hide');

			// add progress indicator, back button, & submit
			$this.append(
				'<div class="custom-footer">'+
					'<div class="s1">'+
						'<span class="progress-indicator"><span class="current">'+ current_index +'</span> / <span clas="total">'+ total_fields +'</span></span>'+
					'</div>'+
					'<div class="s2">'+
						'<span class="back-btn hide"></span>'+
						'<button class="custom-submit-btn btn hide">Submit</button>'+
					'</div>'+
				'</div>'
			);
			
			$back_btn = $this.find('.back-btn');
			$custom_submit_btn = $this.find('.custom-submit-btn');

			// add next buttons
			$fields.each(function() {
				$(this).append('<span class="next-btn"></span>');
			});

			var form_submit_enabled = false;

			// On next click
			$this.find('.next-btn').on('click', function() {
				var field_container = $(this).closest('.gfield'),
					field = field_container.find('input,textarea'),
					validation_success = validate_field(field, field_container);

				//console.log({field_container, field});
				if( validation_success ) {

					if( current_index < total_fields ) {
						show_field(current_index, $this, 'next');
						current_index++;
						update_progress_indicator( current_index, total_fields, $back_btn, $custom_submit_btn, $this );
					}
					
					if( current_index == total_fields ) {
						if( form_submit_enabled ) {
							// Submit
							submit_form($form);
						}
						form_submit_enabled = true;
					} else if ( current_index < total_fields ) {
						form_submit_enabled = false;
					}
					
				}
			});

			// Enable submit button
			$custom_submit_btn.click(function(){
				$this.find('li.gfield:eq('+ (current_index-1) +') .next-btn').click();
			});
			
			$this.find('input, textarea').on('keypress', function(e) {
				if(e.which == 13) {
					// Simulate next button click on enter
					$(this).closest('.gfield').find('.next-btn').click();
				}
			});

			$back_btn.on('click', function(){
				show_field( current_index, $this, 'previous' );
				current_index--;
				update_progress_indicator( current_index, total_fields, $back_btn, $custom_submit_btn, $this );
			});
			
		});

		function validate_field(field, field_container) {
			
			if( field_container.hasClass('gfield_contains_required') ) {
				// validate required
				if( !field.val() || field.val() == '' ) {
					// fail
					show_validation_error(field_container, 'This field is required');
					return false;
				} else {
					// success
					clear_validation_error(field_container);
				}
			}
			
			if( field_container.find('.ginput_container_email').length ) {
				// validate email
				if( !validate_email(field.val()) ) {
					// fail
					show_validation_error(field_container, 'Please enter a valid email');
					return false;
				} else {
					// success
					clear_validation_error(field_container);
				}
			}

			return true; // validation success
		}

		function show_validation_error(field_container, message){
			//console.log('show_validation_error');
			if( !field_container.hasClass('validation-error') ) {
				field_container.addClass('validation-error validation-required').append('<span class="validation-msg">'+ message +'</span>');
			}
		}
		
		function clear_validation_error(field_container) {
			//console.log('clear_validation_error');
			field_container.removeClass('validation-error validation-required').find('.validation-msg').remove();
		}

		function validate_email(email) {
			var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			return re.test(email);
		}
		
		function show_validation_error(field_container, message){
			//console.log('show_validation_error');
			if( !field_container.hasClass('validation-error') ) {
				field_container.addClass('validation-error validation-required').append('<span class="validation-msg">'+ message +'</span>');
			}
		}

		function clear_validation_error(field_container) {
			//console.log('clear_validation_error');
			field_container.removeClass('validation-error validation-required').find('.validation-msg').remove();
		}

		function show_field ( current_index, container, type ) {
			var hide_index = current_index - 1, // Hide current field
				show_index;
			
			if( type == 'next' ) {
				// Show next field
				show_index = current_index; 
			} else {
				// Show previous field
				show_index = current_index - 2; 
			}

			// Hide field
			container.find('li.gfield:eq('+ hide_index +')').addClass('hide');
			// Show field
			container.find('li.gfield:eq('+ show_index +')').removeClass('hide');
		}
		
		function update_progress_indicator( current_index, total_fields, $back_btn, $custom_submit_btn, $this ) {
		
			// Hide back button on first field
			if( current_index < 2 ) {
				$back_btn.addClass('hide');
			} else {
				$back_btn.removeClass('hide');
			}

			// Show submit button on last field
			if ( current_index >= total_fields ) {
				$custom_submit_btn.removeClass('hide');
			} else {
				$custom_submit_btn.addClass('hide');
			}

			$this.find('.progress-indicator .current').text(current_index);
		}

		function submit_form( $form ){
			$form.find('.gform_footer').show(); // show footer to enable form submit
			$form.submit();
			$form.find('.custom-footer').append('<i class="form-submitting fa fa-circle-o-notch fa-spin"></i>');
		}
		
	});
})(jQuery);