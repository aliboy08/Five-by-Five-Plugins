* Create a landing page for the test
	- enter the shortcode [ff_quiz_form] to display the popup form
	- access the popup form with a link that has class "ff-quiz-popup" and href="#ff-quiz-form-popup"
	e.g: <a href="#ff-quiz-form-popup" class="ff-quiz-popup">Take the test</a>

* Create a page for the questionaire
	- enter the shortcode [ff_quiz_questionaire]

* Plugin Settings:
	- set "Quiz landing page" you created above on the settings
	- set "Questionaire page" you created above on the settings

* After user inputs the details on the landing page form, it will redirect to the questionaire page

* Email template tags:
[first_name]
[last_name]
[total_score]
[category_scores]