<?php
global $post;
$p_id = $post->ID;

echo '<div class="ff-quiz-entry-user-details">';
	echo '<h3>User details</h3>';
	$form_fields = get_option('ff_quiz_form_fields');
	echo '<table class="ff-quiz-table-2">';
	foreach( $form_fields as $field ) {

		if( $field['type'] == 'checkbox' ) continue;

		$field_meta = get_post_meta($p_id , $field['slug'], true);
		if( $field_meta ) {
			echo '<tr>';
				echo '<td class="l">'. $field['label'] .'</td>';
				echo '<td class="v">'. $field_meta .'</td>';
			echo '</tr>';
		}
	}
	echo '</table>';

	// Display Checkboxes
	foreach( $form_fields as $field ) {
		if( $field['type'] == 'checkbox' ) {
			$field_meta = get_post_meta($p_id , $field['slug'], true);
			if( $field_meta ) {
				echo '<p class="cb"><strong>'. $field['label'] .'</strong></p>';
			}
		}
	}

echo '</div>';

// Category Scores
echo '<div class="ff-quiz-entry-category-scores">';
	echo '<table class="ff-quiz-table-1">';
		// Category points
		$category_scores = get_post_meta($p_id, 'category_scores', true);
		foreach( $category_scores as $c ) {
			echo '<tr>';
				echo '<td><strong>'. $c['category_name'] .'</strong></td>';
				echo '<td><span class="score">'. $c['score'] .'</span></td>';
			echo '</tr>';
		}
		
		// Total points
		$total_score = get_post_meta($p_id, 'total_score', true);
		echo '<tr class="total">';
			echo '<td><strong>TOTAL</strong></td>';
			echo '<td><span class="score">'. $total_score .'</span></td>';
		echo '</tr>';

	echo '</table>';
echo '</div>';

// Questions
echo '<div class="ff-quiz-entry-questions">';
	echo '<table class="ff-quiz-table-1">';
		echo '<tr>';
			echo '<th class="c1" wp_idth="30">#</th>';
			echo '<th class="c2">Question</th>';
			echo '<th class="c3">Answered</th>';
		echo '</tr>';
		
		$questions_count = get_post_meta($p_id, 'questions_count', true);
		for( $i = 1; $i <= $questions_count; $i++ ) {
			$question = get_post_meta($p_id, 'q_'. $i .'', true);
			$answer = get_post_meta($p_id, 'q_'. $i .'_answer', true);
			echo '<tr>
				<td>'. $i .'</td>
				<td>'. $question .'</td>
				<td><strong>'. $answer .'</strong></td>
			</tr>';
		}

	echo '</table>';
echo '</div>';
