<?php
if( isset($_POST['create_pages']) ) {
		
	// Check if page already exists
	$page_title = 'Online Test';
	$check_page_exists = get_page_by_title( $page_title );
	if( !$check_page_exists ) {
		pre_debug('Page does not exist');

		$page_content = '[ff_quiz_questionaire]';
		// Create page
		$page = array(
			'post_type' => 'page',
			'post_title' => $page_title,
			'post_content' => $page_content,
			'post_status' => 'publish',
		);

		wp_insert_post( $page );

		if( $page ) {
			pre_debug('Page created');
		} else {
			pre_debug('Page was not created');
		}
		
	} else {
		pre_debug('Page already exists');
	}

}
?>
<form class="ff-quiz-tools" action="" method="post">
	<input type="submit" class="button button-primary" value="Create Pages" name="create_pages"/>
</form>