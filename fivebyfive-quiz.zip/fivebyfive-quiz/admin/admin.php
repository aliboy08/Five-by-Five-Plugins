<?php
class FFQuizAdmin
{

	public $question_index = 0;

   public function __construct()
   {
		add_action( 'admin_menu', array( $this, 'admin_pages' ) );
		add_action( 'admin_notices', array( $this, 'custom_admin_notices' ) );

		add_filter( 'manage_edit-ff_quiz_entries_columns', array( $this, 'edit_columns_entries' ) );
		add_filter( 'manage_edit-ff_quiz_entries_sortable_columns', array( $this, 'edit_sortable_columns_entries' ) );
		add_action( 'manage_ff_quiz_entries_posts_custom_column' , array( $this, 'display_columns_entries' ), 10, 2 );

		add_filter( 'manage_edit-ff_quiz_questions_columns', array( $this, 'edit_columns_questions' ) );
		add_filter( 'manage_edit-ff_quiz_questions_sortable_columns', array( $this, 'edit_sortable_columns_questions' ) );
		add_action( 'manage_ff_quiz_questions_posts_custom_column' , array( $this, 'display_columns_questions' ), 10, 2 );
		
		is_admin() && add_action( 'pre_get_posts', array($this, 'custom_admin_posts_order') );

		add_action('admin_enqueue_scripts', array($this, 'load_assets') );
		add_action('admin_init', array($this, 'admin_init') );
	}
	
	public function load_assets()
	{
		$current_screen = get_current_screen();
		if (
			strpos($current_screen->post_type, 'ff_quiz_entries') !== false ||
			strpos($current_screen->post_type, 'ff_quiz_questions') !== false ||
			strpos($current_screen->id, 'ff-quiz_page_ff-quiz-settings') !== false
		) {
			wp_enqueue_style('ff_quiz_styles', plugin_dir_url( __FILE__ ) . 'css/admin-styles.css');
		}

		if( strpos($current_screen->id, 'ff-quiz_page_ff-quiz-settings') !== false ) {
			wp_enqueue_script('jquery-repeater', plugin_dir_url( __FILE__ ) . 'js/jquery.repeater.min.js', array('jquery'), null, true);
			wp_enqueue_script('ff_quiz_scripts', plugin_dir_url( __FILE__ ) . 'js/admin-scripts.js', array('jquery'), null, true);
		}
	}

	public function admin_init()
	{

		// Default form fields
		$default_form_fields = array(
			array(
				'slug' => 'first_name',
				'label' => 'First Name',
				'type' => 'text',
				'required',
			),
			array(
				'slug' => 'last_name',
				'label' => 'Last Name',
				'type' => 'text',
				'required',
			),
			array(
				'slug' => 'email',
				'label' => 'Email Address',
				'type' => 'email',
				'required',
			),
			array(
				'slug' => 'phone',
				'label' => 'Phone',
				'type' => 'text',
			),
		);
		add_option( 'ff_quiz_form_fields', $default_form_fields, '', true );

		// Default answers
		$default_answers = array(
			'Yes' => 2,
			'Somewhat' => 1,
			'No' => 0,
		);
		add_option( 'ff_quiz_answers', $default_answers, '', true );

$default_email_template = '<h2>Hi [first_name], Congratulations on recently completing the Quiz.</h2>

<p>We\'ve scored your answers against the five core criteria, giving you a score out of 10 for each. A score of 8-10 is high, 4-7 is moderate and 1-4 is low As you have seen, your total Quotient score is [total_score]</p>

<p>And, here are each of your section scores, for each categories:</p>

[category_scores]';

		add_option( 'ff_quiz_email_template_body', $default_email_template, '', true );

		add_option( 'ff_quiz_email_subject', 'Online Quiz', '', true );
		add_option( 'ff_quiz_email_from', get_bloginfo( 'name' ), '', true );

	}	

   // Add options page
   public function admin_pages()
   {

		$top_menu_slug = 'edit.php?post_type=ff_quiz_entries';

      add_menu_page(
         'FF Quiz',
         'FF Quiz',
         'manage_options',
         $top_menu_slug
		);

		add_submenu_page(
			$top_menu_slug,
			'Entries',
			'Entries',
			'manage_options',
			'edit.php?post_type=ff_quiz_entries'
		);
		
		add_submenu_page(
			$top_menu_slug,
			'Questions',
			'Questions',
			'manage_options',
			'edit.php?post_type=ff_quiz_questions'
		);

		add_submenu_page(
			$top_menu_slug,
			'Question Categories',
			'Question Categories',
			'manage_options',
			'edit-tags.php?taxonomy=ff_quiz_question_cat&post_type=ff_quiz_questions'
		);
		
		add_submenu_page(
			$top_menu_slug,
			'Settings',
			'Settings',
			'manage_options',
			'ff-quiz-settings',
			array( $this, 'admin_page_settings' )
		);

		add_submenu_page(
			$top_menu_slug,
			'Tools',
			'Tools',
			'manage_options',
			'ff-quiz-tools',
			array( $this, 'admin_page_tools' )
		);
	}

	public function edit_columns_entries( $columns )
	{
		unset( $columns['title'] );
		unset( $columns['date'] );

		$form_fields = get_option('ff_quiz_form_fields');
		foreach( $form_fields as $field ) {
			if( !isset($field['exclude_column']) ){
				$columns[$field['slug']] = $field['label'];
			}
		}

		$columns['entry_date'] = __('Date', 'ff');
		$columns['actions'] = __('Actions', 'ff');

		return $columns;
	}

	public function display_columns_entries( $column, $post_id ){

		$form_fields = get_option('ff_quiz_form_fields');
		foreach( $form_fields as $field ) {
			if( $column == $field['slug'] ) {
				echo get_post_meta( $post_id, $field['slug'], true);
			}
		}

		if( $column == 'entry_date' ) {
			echo get_the_date('Y-m-d h:i:s', $post_id);
		}

		if( $column == 'actions' ) {
			echo '<a href="post.php?post='. $post_id .'&action=edit" class="button button-primary">View</a>';
		}
	
	}
	
	public function edit_sortable_columns_entries( $columns ) {
		$form_fields = get_option('ff_quiz_form_fields');
		foreach( $form_fields as $field ) {
			if( !isset($field['exclude_column']) ){
				$columns[$field['slug']] = $field['label'];
			}
		}
		$columns['entry_date'] = __('Date', 'ff');
		return $columns;
	}

	public function edit_columns_questions( $columns )
	{
		unset( $columns['title'] );
		unset( $columns['date'] );
		$columns['number'] = __('#', 'ff');
		$columns['title'] = __('Question', 'ff');
		$columns['category'] = __('Category', 'ff');
		return $columns;
	}

	public function display_columns_questions( $column, $post_id ){
		switch ( $column ) {
			case 'number' :

				$this->question_index++;

				$paged = get_query_var( 'paged' );
				$posts_per_page = get_query_var( 'posts_per_page' );

				$pagination_index = 0;
				if( $paged > 1 ) {
					$pagination_index = ( $paged - 1 ) * $posts_per_page;
				}
				
				echo $pagination_index + $this->question_index;
				break;

			case 'category' :
				$category = wp_get_post_terms($post_id, 'ff_quiz_question_cat');
				if( $category ) {
					echo $category[0]->name;
				}
				break;
	  }
	}
	
	public function edit_sortable_columns_questions( $columns ) {
		$columns['first_name'] = __('First Name', 'ff');
		$columns['last_name'] = __('Last Name', 'ff');
		$columns['country'] = __('Country', 'ff');
		$columns['phone'] = __('Phone', 'ff');
		$columns['email'] = __('Email', 'ff');
		return $columns;
	}
	
	public function admin_page_settings()
	{
		echo '<h2>Settings</h2>';
		include('admin-settings.php');
	}

	public function admin_page_tools()
	{
		echo '<h2>Tools</h2>';
		include('admin-tools.php');
	}

	public function custom_admin_notices() {
		$screen = get_current_screen();
		// back button - questionaire
		if ( is_admin() && ($screen->id == 'ff_quiz_questions') ) {
			add_action( 'edit_form_after_title', function(){
				echo '<div style="margin:10px 0;">';
					echo '<a class="button button-primary" href="edit.php?post_type=ff_quiz_questions">Back to questions</a>';
				echo '</div>';
			});
		}
		// back button - entries
		if ( is_admin() && ($screen->id == 'ff_quiz_entries') ) {
			add_action( 'edit_form_after_title', function(){
				echo '<div style="margin:10px 0;">';
					echo '<a class="button button-primary" href="edit.php?post_type=ff_quiz_entries">Back to entries</a>';
				echo '</div>';

				echo '<div class="">';
					include('entry-details.php');
				echo '</div>';
			});
		}
	}

	public function custom_admin_posts_order( $query ) 
	{   
		if( $query->get( 'post_type' ) == 'ff_quiz_questions' ) {
			$query->set( 'order', 'ASC');
			$query->set( 'posts_per_page', 50);
		}

		if( $query->get( 'post_type' ) == 'ff_quiz_entries'  ) {
			$query->set( 'posts_per_page', 50);
		}
	}
}

if( is_admin() ) new FFQuizAdmin();
