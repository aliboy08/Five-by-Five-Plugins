(function($){
	$(function(){

		$('.repeater').repeater({
			repeaters: [{
				selector: '.inner-repeater'
			}],
			hide: function (deleteElement) {
				if(confirm('Are you sure you want to remove this item?')) {
				  $(this).slideUp(deleteElement);
				}
			}
		});

	})
})(jQuery)