<?php
if( isset($_POST['ff_quiz_settings']) ) {
	echo '<div class="updated settings-error notice is-dismissible" style="margin:10px 0;"> 
	<p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>';
	
	unset($_POST['ff_quiz_settings']);
	unset($_POST['submit']);
	
	foreach( $_POST as $key => $value ) {
		update_option($key, $value, true);
	}

	if( !isset($_POST['ff_quiz_display_back_btn']) ) {
		update_option('ff_quiz_display_back_btn', 0, true);
	}
}
?>

<form class="repeater ff-quiz-settings-form" action="" method="post">
	
	<div class="settings-group settings-group-1">

		<!-- Form Header -->
		<h4 class="h">Form Header markup</h4>
		<textarea name="ff_quiz_form_header" class="form-heading" placeholder="Enter form header markup"><?php echo stripslashes(get_option('ff_quiz_form_header')) ?></textarea>

		<!-- Fields -->
		<h4 class="h mt-30">Fields to display</h4>
		<table data-repeater-list="ff_quiz_form_fields">
			<tr>
				<th class="c1">Field Slug</th>
				<th class="c2">Field Label</th>
				<th class="c3">Field Type</th>
				<th class="c4">Position</th>
				<th class="c5">Required</th>
				<th class="c6">Exclude in post columns</th>
				<th class="c7">Actions</th>
			</tr>

			<?php
			$field_types = array(
				'text' => 'Text',
				'email' => 'Email',
				'checkbox' => 'checkbox',
			);
			$field_position = array(
				'full' => 'Full',
				'left' => 'Left',
				'right' => 'Right',
			);
			$form_fields = get_option('ff_quiz_form_fields');
			$i = 0;
			foreach( $form_fields as $field ) { $i++;
				?>
				<tr data-repeater-item>

					<!-- Slug -->
					<td class="field-container c1">
						<?php echo '<input type="text" name="ff_quiz_form_fields['. $i .'][slug]" value="'. $field["slug"] .'" placeholder="slug"/>'; ?>
					</td>

					<!-- Label -->
					<td class="field-container c2">
						<?php echo '<input type="text" name="ff_quiz_form_fields['. $i .'][label]" value="'. $field["label"] .'" placeholder="label"/>'; ?>
					</td>

					<!-- Type -->
					<td class="field-container c3">
						<select name="type">
							<?php
							foreach( $field_types as $value => $label ) {
								$selected = ( $field['type'] == $value ) ? ' selected' : '';
								echo '<option value="'. $value .'"'. $selected .'>'. $label .'</option>';
							}
							?>
						</select>
					</td>
					
					<!-- Position -->
					<td class="field-container c4">
						<select name="position">
							<?php
							foreach( $field_position as $value => $label ) {
								$selected = ( $field['position'] == $value ) ? ' selected' : '';
								echo '<option value="'. $value .'"'. $selected .'>'. $label .'</option>';
							}
							?>
						</select>
					</td>
					
					<!-- Required -->
					<td class="field-container c5">
						<?php
						$checked = ( isset($field['required']) ) ? ' checked' : '';
						echo '<input type="checkbox" name="required" value="1"'. $checked .'>';
						?>
					</td>
					
					<!-- Exclude in post columns -->
					<td class="field-container c6">
						<?php
						$checked = ( isset($field['exclude_column']) ) ? ' checked' : '';
						echo '<input type="checkbox" name="exclude_column" value="1"'. $checked .'>';
						?>
					</td>
					
					<!-- Actions -->
					<td class="c7">
						<a href="#" data-repeater-delete type="button" class="remove">Remove</a>
					</td>

				</tr>
				<?php
			}
			?>
			
		</table>
		
		<input data-repeater-create type="button" value="Add Field" class="add-row"/>
	</div>

	<!-- Answer Points -->
	<div class="settings-group settings-group-2">
		<table>
			<tr>
				<th>Answer</th>
				<th>Points</th>
			</tr>
			<?php
			$answers = get_option('ff_quiz_answers');
			if( $answers ) {
				$i = 0;
				foreach( $answers as $key => $value ) { $i++;
					echo '<tr>';
						echo '<td><input type="text" name="ff_quiz_answers['. $key .']" placeholder="Answer '. $i .'" value="'. $key .'"></td>';
						echo '<td><input type="text" name="ff_quiz_answers['. $key .']" placeholder="Answer '. $i .' points" value="'. $value .'"></td>';
					echo '</tr>';
				}
			}
			?>
		</table>
	</div>

	<!-- Questionaire Options -->
	<div class="settings-group settings-group-3">
		<h3 class="h">Questionaire</h3>

		<?php
		$pages = get_posts(array(
			'post_type' => 'page',
			'showposts' => -1,
			'orderby' => 'title',
			'order' => 'ASC',
		));
		?>
		
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row">
						<label>Quiz landing page</label>
					</th>
					<td>
						<select name="ff_quiz_landing_page">
						<?php
						foreach( $pages as $p ) {
							$selected = ( $p->ID == get_option('ff_quiz_landing_page')) ? ' selected' : '';
							echo '<option value="'. $p->ID .'"'. $selected .'>'. $p->post_title .'</option>';
						}
						?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Questionaire page</label>
					</th>
					<td>
						<select name="ff_quiz_questionaire_page">
						<?php
						foreach( $pages as $p ) {
							$selected = ( $p->ID == get_option('ff_quiz_questionaire_page')) ? ' selected' : '';
							echo '<option value="'. $p->ID .'"'. $selected .'>'. $p->post_title .'</option>';
						}
						?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Logo</label>
					</th>
					<td>
						<input class="regular-text" type="text" name="ff_quiz_logo" placeholder="Enter image url" value="<?php echo get_option('ff_quiz_logo'); ?>"/>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Intro content</label>
					</th>
					<td>
						<textarea name="ff_quiz_intro" placeholder="Enter intro content"><?php echo stripslashes(get_option('ff_quiz_intro')) ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Outro content</label>
					</th>
					<td>
						<textarea name="ff_quiz_outro" placeholder="Enter outro content"><?php echo stripslashes(get_option('ff_quiz_outro')) ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Display back button</label>
					</th>
					<td>
						<?php $checked = ( get_option('ff_quiz_display_back_btn') == 1 ) ? ' checked' : ''; ?>
						<input type="checkbox" name="ff_quiz_display_back_btn" value="1" <?php echo $checked; ?>>
					</td>
				</tr>
			</tbody>
		</table>
	</div><!-- Questionaire Options -->

	<!-- Email Options -->
	<div class="settings-group settings-group-4">
		<h3 class="h">Email</h3>
		<table class="form-table">
			<tbody>
				<tr>
					<th scope="row">
						<label>Email subject</label>
					</th>
					<td>
						<input class="regular-text" type="text" name="ff_quiz_email_subject" placeholder="Enter email subject" value="<?php echo get_option('ff_quiz_email_subject'); ?>"/>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Email from</label>
					</th>
					<td>
						<input class="regular-text" type="text" name="ff_quiz_email_from" placeholder="Enter email from" value="<?php echo get_option('ff_quiz_email_from'); ?>"/>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Email template header</label>
					</th>
					<td>
						<textarea name="ff_quiz_email_template_header" placeholder="Enter email template header"><?php echo stripslashes(get_option('ff_quiz_email_template_header')) ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Email template body</label>
					</th>
					<td>
						<textarea name="ff_quiz_email_template_body" placeholder="Enter email template body"><?php echo stripslashes(get_option('ff_quiz_email_template_body')) ?></textarea>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label>Email template footer</label>
					</th>
					<td>
						<textarea name="ff_quiz_email_template_footer" placeholder="Enter email template footer"><?php echo stripslashes(get_option('ff_quiz_email_template_footer')) ?></textarea>
					</td>
				</tr>
			</tbody>
		</table>
	</div><!-- Email Options -->

	<div class="mt-30">
		<input type="hidden" name="ff_quiz_settings">
		<?php submit_button(); ?>
	</div>
</form>