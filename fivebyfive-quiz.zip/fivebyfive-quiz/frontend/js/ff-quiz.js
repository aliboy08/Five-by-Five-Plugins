(function($){
	$(function(){
		
		var category_scores = [],
			 category_scores_percentage = [],
			 question_answers = [];

		var category, point, question, answer, next_slide, next_slide_index, parent;
		
		var input_record = []; // for back functionality

		var slides_count = $('.ff-quiz-questionaire .slide').length;

		updateProgressBar(1);

		// fancybox
		$('.ff-quiz-popup').fancybox({
			'type':'inline',
			'autoDimensions':true,
			'scrolling':'no',
			'opacity':false,
			'hideOnContentClick':false,
			'titleShow':false
		});

		// Next slide
		$('.ff-quiz-questionaire .next-slide').click(function(e){
			e.preventDefault();
			parent = $(this).closest('.slide');
			parent.removeClass('active');
			next_slide = parent.next('.slide');
			next_slide.addClass('active');
			next_slide_index = next_slide.data('slide-index');

			updateCategoryImage(next_slide.data('category-slug'))

			updateProgressBar(next_slide_index);
			
			// Choice
			if(parent.hasClass('question')) {
				category = parent.data('category');
				point = $(this).data('point');
				question = parent.find('.q').text();
				answer = $(this).text();

				//$(this).addClass('clicked');
				updateScore(category, point, question, answer, 'add');
			}

			// Last slide
			if( next_slide_index == slides_count ) {
				// Display category scores
				displayCategoryScores();
				// Send data to WP for post save
				saveUserInput();
				$('.ff-quiz-questionaire .slides-container').addClass('complete');
			}	

		});

		// Previous slide / back
		$('.ff-quiz-questionaire .prev-slide').click(function(e){
			e.preventDefault();
			parent = $(this).closest('.slide');
			parent.removeClass('active');
			prev_slide = parent.prev('.slide');
			prev_slide.addClass('active');
			prev_slide_index = prev_slide.data('slide-index');
			updateCategoryImage(prev_slide.data('category-slug'));
			updateProgressBar(prev_slide_index);
			updateScore(null, null, null, null, 'subtract');
		});

		function updateCategoryImage(category_slug){
			var previous_active_cat = $('.ff-quiz-category-images .cat.active');
			if( previous_active_cat.length ) {
				// Have previous active
				// remove active
				previous_active_cat.removeClass('active'); 
				// reset image
				var prev_img = previous_active_cat.find('img');
				prev_img.attr('src', prev_img.data('initial-image'));
			}

			var set_active_cat = $('.ff-quiz-category-images .cat-'+ category_slug);
			if( set_active_cat.length ) {
				set_active_cat.addClass('active');
				var img = set_active_cat.find('img');
				img.attr('src', img.data('active-image'));
			}
		}

		function updateProgressBar(current_slide_index){
			var percent = current_slide_index / slides_count * 100;
			$('.ff-quiz-progress-bar .fill').css('width', percent+'%');
		}

		function updateScore(category, point, question, answer, action){

			if( typeof action === 'undefined' ) action = 'add';

			if( action == 'add' ) {
				// Sum up category scores
				if( category in category_scores ) {
					// key already exists
					category_scores[category] += point;
				} else {
					// create new key
					category_scores[category] = point;
				}
				// Save question answer
				question_answers.push({
					'question': question,
					'answer': answer
				});

				// Store for back functionality
				input_record.push({
					'category': category,
					'point': point,
				});

			} else if ( action == 'subtract' ) {
				// Subtract category score, with the last input
				category_scores[input_record[input_record.length-1].category] -= input_record[input_record.length-1].point;
				input_record.pop(); // remove last item
			}

		}

		function displayCategoryScores(){
			var o = '';
			for (var category in category_scores) {

				var categoryPercentage = getCategoryPercentage(category, category_scores[category], 10);
				
				category_scores_percentage.push({
					'category_name': category,
					'score': categoryPercentage,
				})

				if (category_scores.hasOwnProperty(category)) {
					o += '<tr>';
						o += '<td class="category '+ category.toLowerCase().replace(/ /g, '-') +'">'+ category +'</td>';
						//o += '<td class="points">'+ category_scores[category] +'</td>';
						o += '<td class="points">'+ categoryPercentage +'</td>';
					o += '</tr>';
				}
			}
			
			$('.ff-quiz-category-results tbody').append(o);
			$('.ff-quiz-questionaire .category-images-container').hide();
			$('.ff-quiz-progress-bar').hide();

			// replace email tag with user input email
			var input_email = $('#ff-quiz-user-details input[name="email"]').val();
			var replaced_tag = $('.outro-content').html().replace('[email]', input_email);
			$('.outro-content').html(replaced_tag);

			// reposition category results table
			$('#display_category_scores').before($('.category-results-container'));
			
		}

		function getCategoryPercentage(categoryName, categoryScore, divideBy){
			var categoryQuestionsCount = $('.slide[data-category="'+ categoryName +'"]').length;
			
			// 100%
			var percentage = categoryScore / ( categoryQuestionsCount * ff_quiz.highest_point ) * 100;
			percentage = percentage / divideBy;

			// Check if number has decimal places
			if( percentage % 1 != 0 ) {
				// decimal
				percentage = percentage.toFixed(1); // 1 decimal place only
			}

			return percentage;
		}

		function getTotalScore(){
			var total_score = 0;
			category_scores_percentage.forEach(function(e){
				total_score += parseInt(e.score);
			});

			total_score = total_score / category_scores_percentage.length;

			if( total_score % 1 != 0 ) {
				total_score = total_score.toFixed(1); // 1 decimal place only
			}

			return total_score;
		}

		function saveUserInput(){
			
			var data = {
				user_details: {},
				user_answers: question_answers,
				user_answers_count: question_answers.length,
				category_scores: category_scores_percentage,
				total_score: getTotalScore(),
			};
			
			// User Details
			$('#ff-quiz-user-details input').each(function(){
				data.user_details[$(this).attr('name')] = $(this).attr('value');
			});

			$.post(ff_quiz.ajax_url, { 'action' : 'ff_quiz_save_user_entry', 'data' : data, }, function(response) {
				console.log('response', response);
			});

		}

		$('#test-email-send').click(function(){
			$.post(ff_quiz.ajax_url, { 'action' : 'ff_quiz_test_email', 'data' : 'test', }, function(response) {
				console.log('response', response);
			});
		})

	})
})(jQuery)