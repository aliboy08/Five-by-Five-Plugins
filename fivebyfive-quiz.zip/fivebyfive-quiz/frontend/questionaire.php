<?php
echo '<div class="ff-quiz-questionaire">';

	// Progress bar
	echo '<div class="ff-quiz-progress-bar-container">';
		echo '<div class="ff-quiz-progress-bar"><span class="fill"></span></div>';
	echo '</div>';
	
	echo '<div class="slides-container">';

		echo '<div class="s1 category-images-container">';
			$this->display_category_images();
		echo '</div>';

		echo '<div class="s2">';
			$slide_index = 0;

			// Intro
			$intro = get_option('ff_quiz_intro');
			if( $intro ) {
				$slide_index++;
				$active = ( $slide_index == 1 ) ? ' active' : '';
				echo '<div class="slide slide-'. $slide_index .' intro-content'. $active .'" data-slide-index="'. $slide_index .'">';
					echo stripslashes($intro);
				echo '</div>';
			}

			$back_btn = '';
			if( get_option('ff_quiz_display_back_btn') == 1 ) {
				$back_btn = '<div class="back-container"><a href="#back" class="prev-slide">Back one step</a></div>';
			}

			// Questions
			$choices = get_option('ff_quiz_answers');
			$categories = ff_quiz_get_category_questions();
			$step = 0;
			$question_index = 0;
			
			foreach( $categories as $category ) {
				$step++;
				foreach( $category['questions'] as $question ) {
					$slide_index++;
					$question_index++;
					$active = ( $slide_index == 1 ) ? ' active' : '';
					echo '<div
						class="slide slide-'. $slide_index .' question-'. $question_index .' question'. $active .'"
						data-category="'. $category['category_name'] .'"
						data-category-slug="'. $category['category_slug'] .'"
						data-slide-index="'. $slide_index .'">';

						echo '<h3 class="slide-heading">Step '. $step .': '. $category['category_name'] .'</h3>';
						echo '<p class="q">'. $question['question'] .'</p>';
						echo '<div class="choices">';
							foreach( $choices as $choice => $points ) {
								echo '<a
									class="choice '. sanitize_title($choice) .' next-slide"
									href="#'. $choice .'"
									data-point="'. $points .'" 
									data-meta-key="q_'. $question_index .'">'. $choice .'</a>';
							}
						echo '</div>';

						if( $slide_index > 2 ) {
							echo $back_btn;
						}
						
					echo '</div>';
				}
			}

			// Results
			$slide_index++;
			echo '<div class="slide slide-'. $slide_index .' outro-content" data-slide-index="'. $slide_index .'">';

				$outro = get_option('ff_quiz_outro');
				if( $outro ) echo stripslashes($outro);

				echo '<div class="category-results-container">';
					echo '<table class="ff-quiz-category-results">';
						echo '<tbody>';
							echo '<tr>';
								echo '<th class="c1">Category</th>';
								echo '<th class="c2">Score</th>';
							echo '</tr>';
						echo '</tbody>';
					echo '</table>';
				echo '</div>';

			echo '</div>'; // slide-outro

		echo '</div>'; // s2
		
	echo '</div>'; // slides-container

	// User details
	echo '<form style="display:none" id="ff-quiz-user-details">';
		$form_fields = get_option('ff_quiz_form_fields');
		foreach( $form_fields as $form_field ) {
			if( isset($_POST['ff_quiz_'. $form_field['slug']]) ) {
				echo '<input type="hidden" name="'. $form_field['slug'] .'" value="'. $_POST['ff_quiz_'. $form_field['slug']] .'">';
			}
		}
	echo '</form>';
	
echo '</div>';