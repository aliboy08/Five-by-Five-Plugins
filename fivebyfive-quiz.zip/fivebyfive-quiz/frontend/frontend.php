<?php
class FFQuizFrontend
{

   public function __construct()
   {
		add_shortcode( 'ff_quiz_form', array($this, 'ff_quiz_form_sc') );
		add_shortcode( 'ff_quiz_questionaire', array($this, 'ff_quiz_questionaire_sc') );
		add_shortcode( 'ff_quiz_display_category_images', array($this, 'display_category_images_sc') );

		add_action( 'wp_enqueue_scripts', array($this, 'register_assets') );

		add_filter( 'body_class', array($this, 'add_body_class') );
	}

	public function register_assets(){
		wp_register_style( 'ff_quiz_styles', plugin_dir_url( __FILE__ ) . 'css/ff-quiz.css' );

		// Fancybox
		wp_register_script( 'jquery-fancybox', plugin_dir_url( __FILE__ ) .'vendors/fancybox/jquery.fancybox.1.3.21.min.js', array('jquery'), null, true );
		wp_register_style( 'fancybox', plugin_dir_url( __FILE__ ) .'vendors/fancybox/jquery.fancybox.1.3.21.css', false, null, 'screen' );

		wp_register_script( 'ff_quiz_scripts', plugin_dir_url( __FILE__ ) . 'js/ff-quiz.js', array('jquery', 'jquery-fancybox'), null, true );
	}

	public function load_assets(){
		wp_enqueue_style( 'ff_quiz_styles' );

		// Fancybox
		wp_enqueue_script( 'jquery-fancybox' );
		wp_enqueue_style( 'fancybox' );

		wp_localize_script( 'ff_quiz_scripts', 'ff_quiz', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'highest_point' => ff_quiz_setting_get_highest_answer_points(),
		) );
		wp_enqueue_script( 'ff_quiz_scripts' );
	}
	
	public function ff_quiz_form_sc()
	{
		$this->load_assets();
		ob_start();
		
		echo '<a href="#" id="test-email-send">TEST EMAIL SEND</a>';

		echo '<div style="display:none">';
			echo '<div class="ff-quiz-form-popup" id="ff-quiz-form-popup">';
				$questionaire_page = get_option('ff_quiz_questionaire_page');
				$questionaire_page_link = get_permalink($questionaire_page);
				echo '<form action="'. $questionaire_page_link .'" id="ff-quiz-form" class="ff-quiz-form" method="post">';
					$this->render_form_header();
					$this->render_form_fields();
				echo '</form>';
			echo '</div>';
		echo '</div>';
		return ob_get_clean();
	}
	
	public function add_body_class( $classes )
	{
		if( is_page( get_option('ff_quiz_landing_page') ) ) {
			$classes[] = 'ff-quiz-landing-page';
		}
		if( is_page( get_option('ff_quiz_questionaire_page') ) ) {
			$classes[] = 'ff-quiz-questionaire-page';
		}
		return $classes;
	}

	public function render_form_fields()
	{
		$form_fields = get_option('ff_quiz_form_fields');
		echo '<div class="form-fields">';

			echo '<div class="before-form-fields">';
				do_action('ff_quiz_before_form_fields');
			echo '</div>';

			foreach( $form_fields as $field ) {
				$type = $field['type'];
				echo '<div class="field-container field-'. $type .' '. $field['position'] .' field_'. $field['slug'] .'">';

					$required = ( isset($field['required']) ) ? ' required' : '';

					if( $type == 'text' || $type == 'email' ) {
						echo '<span class="ff-label">'. $field['label'] .'</span>';
						echo '<span class="ff-field"><input type="'. $type .'" name="ff_quiz_'. $field['slug'] .'" placeholder="'. $field['label'] .'"'. $required .'></span>';
					}
					
					if( $type == 'checkbox' ) {
						echo '<label>';
							echo '<span class="ff-field"><input type="checkbox" name="ff_quiz_'. $field['slug'] .'" value="1"></span>';
							echo '<span class="ff-label">'. $field['label'] .'</span>';
						echo '</label>';
					}
				echo '</div>';
			}

			echo '<div class="field-container full">';
				echo '<input type="submit" value="Submit" class="submit-btn">';
			echo '</div>';

			echo '<div class="after-form-fields">';
				do_action('ff_quiz_after_form_fields');
			echo '</div>';

		echo '</div>';
	}

	public function render_form_header()
	{
		$form_header = get_option('ff_quiz_form_header');
		if( $form_header ) {
			echo '<div class="form-header">';
				echo stripslashes($form_header);
			echo '</div>';
		}
	}

	public function ff_quiz_questionaire_sc()
	{
		$this->load_assets();
		ob_start();
		
		// Check if user details have been inputted
		if( count($_POST) < 1 ) {
			echo '<p><a href="'. get_permalink(get_option('ff_quiz_landing_page')) .'">Enter your details here first</a></p>';
			return;
		}

		include('questionaire.php');
		return ob_get_clean();
	}

	public function display_category_images(){
		$categories = get_terms('ff_quiz_question_cat');

		echo '<div class="ff-quiz-category-images">';
			$i = 0;
			foreach( $categories as $category ) { $i++;
				echo '<span class="cat cat-'. $i .' cat-'. $category->slug .'">';
					$metas = get_option('taxonomy_term_'. $category->term_id);
					$initial_image = ( isset($metas['initial_image']) ) ? $metas['initial_image'] : '';
					$active_image = ( isset($metas['active_image']) ) ? $metas['active_image'] : '';
					echo '<img src="'. $initial_image .'" data-initial-image="'. $initial_image .'" data-active-image="'. $active_image .'" alt="'. $category->name .'">';
				echo '</span>';
			}

			$logo = get_option('ff_quiz_logo');
			if( $logo ) {
				echo '<span class="quiz-logo"><img src="'. $logo .'"></span>';
			}
			
		echo '</div>';
	}

	public function display_category_images_sc(){
		ob_start();
		$this->display_category_images();
		return ob_get_clean();
	}

}

if( !is_admin() ) new FFQuizFrontend();

