<?php
if( !function_exists('pre_debug') ) :
function pre_debug($msg, $return = false ) {
   $o = '<pre>'. print_r($msg, true) .'</pre>';
   if( $return ) {
      return $o;
   } else {
      echo $o;
   }
}
endif;

function ff_quiz_register_post_types_and_taxonomies() {

	/**
	 * Post Type: Quiz Entries.
	 */
	$args = array(
		"label" => __( "Quiz Entries", "" ),
		"labels" => array(
			"name" => __( "Quiz Entries", "" ),
			"singular_name" => __( "Quiz Entry", "" ),
		),
		"description" => "",
		"public" => false,
		"publicly_queryable" => false,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => false,
		"show_in_menu" => false,
		"show_in_nav_menus" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => false,
		"supports" => array( "title", "custom-fields" ),
	);
	register_post_type( "ff_quiz_entries", $args );

	/**
	 * Post Type: Quiz Questions.
	 */
	$args = array(
		"label" => __( "Quiz Questions", "" ),
		"labels" => array(
			"name" => __( "Quiz Questions", "" ),
			"singular_name" => __( "Quiz Question", "" ),
		),
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => false,
		"show_in_menu" => false,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => false,
		"supports" => array( "title", "custom-fields" ),
	);
	register_post_type( "ff_quiz_questions", $args );

	/**
	 * Taxonomy: Question Categories.
	 */
	$args = array(
		"label" => __( "Question Categories", "" ),
		"labels" => array(
			"name" => __( "Question Categories", "" ),
			"singular_name" => __( "Question Category", "" ),
		),
		"public" => false,
		"hierarchical" => true,
		"label" => "Question Categories",
		"show_ui" => true,
		"show_in_menu" => false,
		"show_in_nav_menus" => false,
		"query_var" => false,
		"rewrite" => false,
		"show_admin_column" => false,
		"show_in_rest" => false,
		"rest_base" => "ff_quiz_question_cat",
		"show_in_quick_edit" => true,
	);
	register_taxonomy( "ff_quiz_question_cat", array( "ff_quiz_questions" ), $args );

}

add_action( 'init', 'ff_quiz_register_post_types_and_taxonomies' );

function ff_quiz_get_questions(){
	$questions = array();
	$categories = get_terms('ff_quiz_question_cat');
	foreach( $categories as $category ) {
		$args = array(
			'post_type' => 'ff_quiz_questions',
			'showposts' => -1,
			'order' => 'ASC',
			'tax_query' => array(
				array(
					'taxonomy' => 'ff_quiz_question_cat',
					'field'    => 'slug',
					'terms'    => array( $category->slug ),
				)
			)
		);
		$posts = get_posts( $args );
		$i = 0;
		foreach( $posts as $post ) { $i++;
			$questions[] = array(
				'number' => $i,
				'question' => $post->post_title,
				'category' => $category,
			);
		}
	}
	return $questions;
}

function ff_quiz_get_category_questions(){
	$category_questions = array();
	$categories = get_terms('ff_quiz_question_cat');
	$i = 0;
	foreach( $categories as $category ) {

		// Add each category to array
		$category_questions[$category->slug]['category_name'] = $category->name;
		$category_questions[$category->slug]['category_slug'] = $category->slug;
		
		$args = array(
			'post_type' => 'ff_quiz_questions',
			'showposts' => -1,
			'order' => 'ASC',
			'tax_query' => array(
				array(
					'taxonomy' => 'ff_quiz_question_cat',
					'field'    => 'slug',
					'terms'    => array( $category->slug ),
				)
			)
		);

		$posts = get_posts( $args );
		if( $posts ) {
			foreach( $posts as $post ) { $i++;
				// Add questions to category array
				$category_questions[$category->slug]['questions'][] = array(
					'number' => $i,
					'question' => $post->post_title,
				);
			}
		}
	}
	return $category_questions;
}

function ff_quiz_save_user_entry() {

	$args = array(
		'post_type' => 'ff_quiz_entries',
		'post_title' => $_POST['data']['user_details']['first_name'] . ' '. $_POST['data']['user_details']['last_name'],
		'post_status' => 'publish',
	);

	$id = wp_insert_post( $args );
	if( $id ) {
		// Entry created

		// User details
		foreach( $_POST['data']['user_details'] as $key => $value ) {
			update_post_meta( $id, $key, $value );
		}

		// Question answers
		$i = 0;
		foreach( $_POST['data']['user_answers'] as $a ) { $i++;
			update_post_meta( $id, 'q_'. $i, $a['question'] );
			update_post_meta( $id, 'q_'. $i .'_answer', $a['answer'] );
		}
		update_post_meta( $id, 'questions_count', $_POST['data']['user_answers_count']);

		// Category Scores
		update_post_meta( $id, 'category_scores', $_POST['data']['category_scores'] );

		// Total score
		update_post_meta( $id, 'total_score', $_POST['data']['total_score'] );

	} else {
		// Entry failed
		echo 'Entry create failed';
	}

	// Send Email
	ff_quiz_send_entry_email( $id );

	wp_die();
}
add_action( 'wp_ajax_ff_quiz_save_user_entry', 'ff_quiz_save_user_entry' );
add_action( 'wp_ajax_nopriv_ff_quiz_save_user_entry', 'ff_quiz_save_user_entry' );


// Quiz Categories Custom Fields
function ff_quiz_question_cat_taxonomy_custom_fields($tag) {
   $t_id = $tag->term_id; // Get the ID of the term you're editing
   $term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check
?>
<tr class="form-field">
   <th scope="row" valign="top">
   	<label for="initial_image"><?php _e('Initial Image'); ?></label>
   </th>
   <td>
   	<input type="text" name="term_meta[initial_image]" id="term_meta[initial_image]" size="25" style="width:60%;" value="<?php echo $term_meta['initial_image'] ? $term_meta['initial_image'] : ''; ?>"><br />
   </td>
</tr>
<tr class="form-field">
   <th scope="row" valign="top">
   	<label for="active_image"><?php _e('Active Image'); ?></label>
   </th>
   <td>
   	<input type="text" name="term_meta[active_image]" id="term_meta[active_image]" size="25" style="width:60%;" value="<?php echo $term_meta['active_image'] ? $term_meta['active_image'] : ''; ?>"><br />
   </td>
</tr>
<?php
}
add_action( 'ff_quiz_question_cat_edit_form_fields', 'ff_quiz_question_cat_taxonomy_custom_fields', 10, 2 );

function ff_save_quiz_cat_taxonomy_custom_fields( $term_id ) {
	if ( isset( $_POST['term_meta'] ) ) {
		$t_id = $term_id;
		$term_meta = get_option( "taxonomy_term_$t_id" );
		$cat_keys = array_keys( $_POST['term_meta'] );
			foreach ( $cat_keys as $key ){
			if ( isset( $_POST['term_meta'][$key] ) ){
				$term_meta[$key] = $_POST['term_meta'][$key];
			}
		}
		//save the option array
		update_option( "taxonomy_term_$t_id", $term_meta );
	}
}
add_action( 'edited_ff_quiz_question_cat', 'ff_save_quiz_cat_taxonomy_custom_fields', 10, 2 );

function ff_quiz_setting_get_highest_answer_points(){
	// Get highest points in the settings
	$answer_points = get_option('ff_quiz_answers');
	$highest_point = 0;
	foreach( $answer_points as $points ) {
		if( $points > $highest_point ) {
			$highest_point = $points;
		}
	}
	return $highest_point;
}

function ff_quiz_send_entry_email( $entry_id ){

	$to = get_post_meta( $entry_id, 'email', true );

	$subject = get_option( 'ff_quiz_email_subject' );
	$body = apply_filters('the_content', ff_quiz_replace_email_tags( $entry_id ));
	
	$headers[] = 'Content-Type: text/html; charset=UTF-8';
	$headers[] = 'From: '. get_option( 'ff_quiz_email_from' );

	if( wp_mail( $to, $subject, $body, $headers ) ) {
		pre_debug('Email sent');
	} else {
		pre_debug('Email did not send');
	}

}

function ff_quiz_test_email(){
	$test_entry_id = 1260;
	ff_quiz_send_entry_email($test_entry_id);
}
add_action( 'wp_ajax_ff_quiz_test_email', 'ff_quiz_test_email' );
add_action( 'wp_ajax_nopriv_ff_quiz_test_email', 'ff_quiz_test_email' );

function ff_quiz_email_template() {
	$email_template = '<div style="width:600px; border: 1px solid #eee; background: #fff;">';
	$email_template_header = get_option( 'ff_quiz_email_template_header' );
	if( $email_template_header ) {
		$email_template_header = stripslashes($email_template_header);
		$email_template .= '<div style="background-color: #f9f9f9; text-align: center;padding:40px;">';
		$email_template .= $email_template_header;
		$email_template .= '</div>';
	}

	$email_template_body = get_option( 'ff_quiz_email_template_body' );
	if( $email_template_body ) {
		$email_template .= '<div style="background:#fefefe;padding:40px;">';
		$email_template_body = stripslashes($email_template_body);
		$email_template .= $email_template_body;
		$email_template .= '</div>';
	}

	$email_template_footer = get_option( 'ff_quiz_email_template_footer' );
	if( $email_template_footer ) {
		$email_template .= '<div style="	background: #FAF9F7;padding: 40px;">';
		$email_template_footer = stripslashes($email_template_footer);
		$email_template .= $email_template_footer;
		$email_template .= '</div>';
	}
	$email_template .= '</div>';
	return $email_template;
}

function ff_quiz_replace_email_tags( $entry_id ) {	

	$output = ff_quiz_email_template();

	$special_tags = array(
		'first_name',
		'last_name',
		'total_score',
		'category_scores',
	);

	foreach( $special_tags as $tag ) {

		$pattern = '/\['. $tag .'\]/i';

		switch( $tag )
		{
			case 'first_name':
				$replace = get_post_meta( $entry_id, 'first_name', true );
				break;
				
			case 'last_name':
				$replace = get_post_meta( $entry_id, 'last_name', true );
				break;

			case 'total_score':
				$replace = get_post_meta( $entry_id, 'total_score', true );
				break;

			case 'category_scores':
				$category_scores = get_post_meta( $entry_id, 'category_scores', true );
				$o = '<table border="0" cellpadding="1" cellspacing="0" bgcolor="#f7f7f7" style="color:#666666;">';
					$o .= '<tr>';
						$o .= '<td>';
							$o .= '<table cellspacing="0" style="width:500px;">';
							foreach( $category_scores as $c ) {
								$o .= '<tr>';
									$o .= '<td style="background:#ffffff;padding:15px;border: 1px solid #F1F1F1;">';
										$o .= $c['category_name'];
									$o .= '</td>';
									$o .= '<td width="176" style="background-color:#F9FAFC;padding:15px 0;border: 1px solid #F1F1F1;text-align:center;font-weight:700;">';
										$o .= $c['score'];
									$o .= '</td>';
								$o .= '</tr>';
							}
							$o .= '</table>';
						$o .= '</td>';
					$o .= '</tr>';
				$o .= '</table>';

				$replace = $o;
				break;
		}

		$output = preg_replace($pattern, $replace, $output);

	}

	return $output;
}