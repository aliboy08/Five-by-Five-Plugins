<?php
/*
Plugin Name: Five by Five Quiz
Description: Create questionaire and save user input easily
Version: 1.0
*/

if ( !defined( 'WPINC' ) ) die;

include('functions.php');
include('admin/admin.php');
include('frontend/frontend.php');