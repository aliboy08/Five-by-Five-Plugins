<?php
if ( ! defined( 'WPINC' ) ) die; // If file is called directly, abort

class FF_MediaBoxes {
	
	private static $instance = null;

	public static function getInstance() {
		if (self::$instance == null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_shortcode( 'ff_custom_media_boxes', array( $this, 'shortcode' ) );
	}
	
	public function register_assets() {
		
		$assets_dir = plugin_dir_url( __FILE__ ) . 'assets/';
		
		// CSS
		//wp_register_style ( 'magnific-popup-stylesheet', $plugin_assets_dir. 'components/Magnific Popup/magnific-popup.css' ); // only use if needed
		wp_register_style ( 'mediaBoxes-stylesheet', $assets_dir .'css/mediaBoxes.css' );

		// JS
		wp_register_script ( 'jquery-isotope', $assets_dir .'components/Isotope/jquery.isotope.min.js', array( 'jquery' ), '2.2.2', true );
		wp_register_script ( 'jquery-imagesLoaded', $assets_dir .'components/imagesLoaded/jquery.imagesLoaded.min.js', array( 'jquery' ), '3.1.8', true );
		wp_register_script ( 'jquery-transit', $assets_dir .'components/Transit/jquery.transit.min.js', array( 'jquery' ), '', true );
		wp_register_script ( 'jquery-easing', $assets_dir .'components/jQuery Easing/jquery.easing.js', array( 'jquery' ), '1.3', true );
		wp_register_script ( 'waypoints', $assets_dir .'components/Waypoints/waypoints.min.js', array( 'jquery' ), '4.0.0', true );
		wp_register_script ( 'modernizr-custom', $assets_dir .'components/Modernizr/modernizr.custom.min.js', array( 'jquery' ), '3.3.1', true );
		//wp_register_script ( 'jquery-magnific-popup', $assets_dir  .'components/Magnific Popup/jquery.magnific-popup.min.js', array( 'jquery' ), '1.1.0', false );
		//wp_register_script ( 'jquery-media-boxes', $assets_dir .'/js/jquery.mediaBoxes.js', array( 'jquery' ), '3.1', false );
		
		wp_register_script ( 'jquery-media-boxes', $assets_dir .'/js/jquery.mediaBoxes.min.js', array( 'jquery' ), '3.1', true );
		wp_register_script ( 'ff-media-boxes-script', $assets_dir .'js/ff-media-boxes-script.js', array( 'jquery' ), '1.0', true );
	}
	
	public function load_assets() {
		// CSS
		wp_enqueue_style( 'mediaBoxes-stylesheet' );

		// JS
		wp_enqueue_script( 'jquery-isotope' );
		wp_enqueue_script( 'jquery-imagesLoaded' );
		wp_enqueue_script( 'jquery-transit' );
		wp_enqueue_script( 'jquery-easing' );
		wp_enqueue_script( 'waypoints' );
		wp_enqueue_script( 'modernizr-custom' );
		wp_enqueue_script( 'jquery-media-boxes' );
	}
	
	public function shortcode( $atts ) {
		
		// Load assets
		$this->load_assets();
		
		ob_start();
		
		// Shortcode Options
		extract( shortcode_atts( array(
			'id' => '',
			'post_type' => 'post',
			'post_types' => '',
			'num' => -1,
			'taxonomy' => 'category',
			'terms' => '',
			'exclude_terms' => '',
			'class' => '',
			'image_class' => 'custom-crop',
			'default_image' => get_stylesheet_directory_uri() .'/images/default-blog.jpg',
			'image_width' => 409,
			'image_height' => 174,
			'image_height_max' => 600,
			'show_filter' => 'false',
			'filter_type' => 'list',
			'filter_heading' => '',
			'filter_taxonomies' => '',
			'filter_taxonomies_label' => '',
			'show_search' => 'false',
			'force_crop' => 'false',
			'hide_bottom_content' => 'false',
			'hide_date' => 'true',
			'hide_read_more' => 'false',
			'disable_link' => 'false',
			'excerpt_length' => 200,
			'title_length_limit' => '',
			'default_selected' => '',
			
			// Media Box Settings
			// http://www.davidbo.dreamhosters.com/plugins/mediaBoxes/documentation/index.html#options
			'box_container' => 'boxes-grid',
			'columns' => 4,
			'column_width' => 'auto',
			'horizontal_space' => 20,
			'vertical_space' => 20,
			'boxes_to_load' => 8,
			'boxes_to_load_start' => 8,
			'minBoxesPerFilter' => 6,
			'lazy_load' => true,
			'overlay_effect' => 'fade',
			'search' => 'boxes-search',
			'no_more_entries_word' => 'No more posts',
			'filter_container' => 'boxes-filter',
		), $atts ) );
		
		if( $filter_taxonomies ) {
			$filter_taxonomies = explode( ',', $filter_taxonomies );
		}

		if( $filter_taxonomies_label ) {
			$filter_taxonomies_label = explode( ',', $filter_taxonomies_label );
		}

		if( $post_types != '' ) {
			$post_type_values = explode( ',', $post_types );
			$post_type = array();
			foreach( $post_type_values as $post_type_value ) {
				array_push( $post_type, $post_type_value );
			}
		}

		$args = array (
			'post_type' => $post_type,
			'showposts' => $num,
			'post_status' => 'publish',
			'tax_query' => array(),
		);
		
		$terms_array = array();
		if( $terms != '' ) {
			$term_values = explode( ',', $terms );
			foreach( $term_values as $term ) {
				array_push( $terms_array, $term);
			}
			$args['tax_query'][] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $terms_array,
			);
		}
		
		$terms_exclude_array = array();
		if( $exclude_terms != '' ) {
			$term_exclude_values = explode( ',', $exclude_terms );
			foreach( $term_exclude_values as $term ) {
				array_push( $terms_exclude_array, $term);
			}
			$args['tax_query'][] = array(
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $terms_exclude_array,
				'operator' => 'NOT IN',
			);
		}
		
		$add_class = ( $class != '' ) ? ' '. $class : '';
		$the_query = new WP_Query( $args );
		
		if ( $the_query->have_posts() ) :
			
			// Filter by categories
			if( $show_filter == 'true' ) {
				
				echo '<div class="media-boxes-filter-container filters-container">';
					echo '<div class="wrapper">';
						echo '<div class="inner">';
							
							// Filter Label
							if( $filter_heading ) {
								echo '<span class="filter-heading">'. $filter_heading .'</span>';
							}
							
							// Search
							echo ( $show_search == 'true' ) ? '<input type="text" class="media-boxes-search '. $search .'" placeholder="Search By Title">' : '';

							if( $filter_type == 'list' ) {

								// Filter - List
								echo '<ul class="media-boxes-filter '.$filter_container .'">';
								
									$selected = ( !$default_selected ) ? 'selected' : '';
									echo '<li><a href="#" data-filter="*" class="'. $selected .'">All</a></li>';
				
									if( $terms != '' ) {

										// Specify terms
										foreach ( $term_values as $filter_cat ) {
											$category = get_term_by( 'slug', $filter_cat, $taxonomy);
											// Default Selected
											$selected = $this->check_default_selected( $default_selected, $category->term_id );
											echo '<li><a class="'. $selected .'" href="#" data-filter=".'. $category->slug .'">'. $category->name .'</a></li>';
										}

									} else {

										// All terms
										$this->render_terms_filter_options( 'list', $taxonomy, $terms_exclude_array, $default_selected);

									}
									
								echo '</ul>';

							} elseif ( $filter_type == 'dropdown' ) {
								
								// Filter - Dropdown
								if( $filter_taxonomies ) {
									echo '<div class="multiple-dropdowns-filter">';
									// Multiple Taxonomies
									$i = 0;
									foreach( $filter_taxonomies as $filter_taxonomy ) {
										echo '<div class="media-boxes-drop-down '. $filter_container .'" data-id="filter-'. $i .'">';
											echo '<div class="media-boxes-drop-down-header"><a class="selected" href="#" data-filter="*">Filter<span class="fa fa-sort-desc"></span></a></div>';
											echo '<ul class="media-boxes-drop-down-menu">';

												if( isset( $filter_taxonomies_label[$i]) && $filter_taxonomies_label[$i] != '' ) {
													echo '<li><a class="selected" href="#">'. $filter_taxonomies_label[$i] .'</a></li>';
												}

												echo '<li><a href="#" data-filter="*">All</a></li>';

												$this->render_terms_filter_options( 'dropdown', $filter_taxonomy, $terms_exclude_array);

											echo  '</ul>';
										echo '</div>';
										$i++;
									}
									echo '</div>';

								} else {

									// Single Taxonomy
									echo '<div class="media-boxes-drop-down '. $filter_container .'">';
										echo '<div class="media-boxes-drop-down-header"><a class="selected" href="#" data-filter="*">Filter<span class="fa fa-sort-desc"></span></a></div>';
										echo '<ul class="media-boxes-drop-down-menu">';

											$selected = ( !$default_selected ) ? 'selected' : '';
											echo '<li><a class="'. $selected .'" href="#" data-filter="*">All</a></li>';

											if( $terms != '' ) {

												// Specify terms
												foreach ( $term_values as $filter_cat ) {
													$category = get_term_by( 'slug', $filter_cat, $taxonomy);
													echo '<li><a href="#" data-filter=".'. $category->slug .'">'. $category->name .'</a></li>';
												}

											} else {

												// All terms
												$this->render_terms_filter_options( 'dropdown', $taxonomy, $terms_exclude_array, $default_selected);

											}

										echo  '</ul>';
									echo '</div>';
								}

							} // dropdown
							
						echo '</div>'; // inner
					echo '</div>'; // wrapper
				echo '</div>'; // filter-container

			} // Filter

			echo '<div class="media-boxes-wrap wrapper">';
				echo '<div id="'. $id .'" class="media-boxes-grid '. $add_class .' '. $box_container .'">';
					while ( $the_query->have_posts() ) : $the_query->the_post();

						$id = get_the_ID();
						$link = get_permalink();
						$title = get_the_title();
						
						// Add class for filtering
						$filter_class = '';
						if ( $show_filter == 'true' ) {
							if( $filter_taxonomies ) {
								// Multiple
								foreach( $filter_taxonomies as $filter_taxonomy ) {
									$filter_class = $this->append_taxonomy_class( $filter_class, $id, $filter_taxonomy );
								}
							} else {
								// Single
								$filter_class = $this->append_taxonomy_class( $filter_class, $id, $taxonomy );
							}
						}
						
						echo '<div class="media-box'. $filter_class .'">';
						
							// Use image class, if set image dimension is smaller, use default placeholder image
							if( has_post_thumbnail() ) {
								$image_url = get_the_post_thumbnail_url( $id, $image_class );
							} else {
								$image_url = $default_image;
							}
							
							echo '<div class="media-box-image">';
								echo '<div data-width="'. $image_width .'" data-height="'. $image_height .'" data-thumbnail="'. $image_url .'"></div>';
								
								echo ( $disable_link != 'true' ) ? '<a href="'. $link .'"><span class="thumbnail-overlay"></span></a>' : '';

								// Category
								$categories = wp_get_post_terms( $id, $taxonomy, array( 'fields' => 'names' ) );
								if( $categories ) {
									echo '<span class="image-tag">';
										echo implode( ', ', $categories );
									echo '</span>';
								}
							echo '</div>';
							
							if( $hide_bottom_content != 'true' ) {
								echo '<div class="media-box-content">';
								
									echo '<div class="media-box-title truncate-text">';
										$a = $title;
										if( $title_length_limit ) $a = wp_trim_words( $a, $title_length_limit, '...' );
										if( $disable_link != 'true' ) {
											$a = '<a href="'. $link .'" class="inherit">'. $a .'</a>';
										}
										echo $a;
									echo '</div>';
								
									echo ( $hide_date != 'true' ) ? '<div class="media-box-date">'. get_the_date() .'</div>' : '';
									echo '<div class="media-box-text truncate-text">';
										echo wp_trim_words( get_the_excerpt(), $excerpt_length, '...' );
									echo '</div>';
									echo ( $hide_read_more != 'true' ) ? '<div class="link-container"> <a href="'. $link .'" class="more-link">Read more</a> </div>' : '';
								echo '</div>';
							}
							
						echo '</div>'; // media-box
						
						
					endwhile;
				echo '</div>';
			echo '</div>'; // media-box-wrap
		endif;
		wp_reset_postdata();
		
		$ff_media_boxes_options = array(
			'box_container' => '.'.$box_container,
			'filterContainer' => '.'.$filter_container,
			'search' => '.'.$search,
			'boxesToLoadStart' => $boxes_to_load_start,
			'boxesToLoad' => $boxes_to_load,
			'lazyLoad' => $lazy_load,
			'horizontalSpaceBetweenBoxes' => $horizontal_space,
			'verticalSpaceBetweenBoxes' => $vertical_space,
			'columns' => $columns,
			'columnWidth' => $column_width,
			'overlayEffect' => $overlay_effect,
			'noMoreEntriesWord' => $no_more_entries_word,
			'magnificPopup' => false,
			'minBoxesPerFilter' => $minBoxesPerFilter,
		);
		
		wp_localize_script( 'ff-media-boxes-script', 'ff_media_boxes_options', $ff_media_boxes_options );
		wp_enqueue_script( 'ff-media-boxes-script' );
		
		return ob_get_clean();
	}

	/**
	 * Add class to post item for filtering
	 * return string
	 */
	public function append_taxonomy_class( $filter_class, $post_id, $taxonomy) {
		$terms = wp_get_post_terms( $post_id, $taxonomy );
		$i = 0;
		foreach ( $terms as $term ) {
			$i++;
			$spacer = ( $i <= 1 ) ? '' : ' ';
			$filter_class .= ' ' . $term->slug;
		}
		return $filter_class;
	}

	/**
	 * Check filter default selected option
	 * return string
	 */
	public function check_default_selected( $default_selected_option, $compare ) {
		if( $default_selected_option != '' ) {
			if( $default_selected_option == $compare ) {
				return 'selected';
			}
		}
		return '';
	}

	/**
	 * Render term as filter options
	 * echo html
	 */
	public function render_terms_filter_options( $type="dropdown", $taxonomy="category", $exclude_terms=array(), $default_selected="") {
		$tax_terms = get_terms( $taxonomy);
		if( $tax_terms ) {
			foreach ( $tax_terms as $term ) {
				if( in_array( $term->slug, $exclude_terms ) || $term->slug == 'uncategorized' ) {
					continue;
				}
				if( $type == 'dropdown' ) {
					// dropdown
					$selected = $this->check_default_selected( $default_selected, $term->slug );
					echo '<li><a class="'. $selected .'" href="#" data-filter=".'. $term->slug .'">'. $term->name .'</a></li>';
				} else {
					// list
					$selected = $this->check_default_selected( $default_selected, $term->slug );
					echo '<li><a class="'. $selected .'" href="#" data-filter=".'. $term->slug .'">'. $term->name .'</a></li>';
				}
			}
		}
	}

}
$ff_media_boxes = FF_MediaBoxes::getInstance();