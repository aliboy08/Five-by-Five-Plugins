<?php
/*
Plugin Name: Five by Five Media Boxes
Description: Display posts in masonry grid
Author: Five by Five
Author URI: http://www.fivebyfive.com.au
Version: 4.0
*/

if ( !defined( 'WPINC' ) ) die;

include('class-ff-media-boxes.php');