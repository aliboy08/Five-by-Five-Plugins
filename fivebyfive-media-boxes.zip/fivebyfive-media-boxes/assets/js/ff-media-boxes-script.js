(function($){
	$(function(){
		//console.log(ff_media_boxes_options);
		if( $(ff_media_boxes_options.box_container).length ) {
			//$( ff_media_boxes_options.box_container ).mediaBoxes();
			var mb = $( ff_media_boxes_options.box_container ).mediaBoxes({
				filterContainer: ff_media_boxes_options.filterContainer,
				search: ff_media_boxes_options.search,
				boxesToLoadStart: parseInt(ff_media_boxes_options.boxesToLoadStart),
				boxesToLoad: parseInt(ff_media_boxes_options.boxesToLoad),
				lazyLoad: JSON.parse(ff_media_boxes_options.lazyLoad),
				horizontalSpaceBetweenBoxes: parseInt(ff_media_boxes_options.horizontalSpaceBetweenBoxes),
				verticalSpaceBetweenBoxes: parseInt(ff_media_boxes_options.verticalSpaceBetweenBoxes),
				columnWidth: ff_media_boxes_options.columnWidth,
				columns: parseInt(ff_media_boxes_options.columns),
				overlayEffect: ff_media_boxes_options.overlayEffect,
				noMoreEntriesWord: ff_media_boxes_options.noMoreEntriesWord,
				magnificPopup: ff_media_boxes_options.magnificPopup,
				minBoxesPerFilter: parseInt(ff_media_boxes_options.minBoxesPerFilter),
				resolutions: [
					{
						maxWidth: 960,
						columnWidth: 'auto',
						columns: 3,
					},
					{
						maxWidth: 767,
						columnWidth: 'auto',
						columns: 2,
					},
					{
						maxWidth: 479,
						columnWidth: 'auto',
						columns: 1,
					},
				],
			});

			// Fix truncate not applying
			mb.on( 'layoutComplete', function() {
				if ( $('.truncate-text, .truncate') && typeof $().dotdotdot !== 'undefined' ) {
					$('.truncate-text, .truncate').dotdotdot();
				}
			});
		}
		
	})
})(jQuery);